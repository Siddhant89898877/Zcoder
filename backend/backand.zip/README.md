# scholarship-finder-backend/README.md
# Scholarship Finder Backend

This project provides a backend API to:
- Scrape scholarships
- Save them in MongoDB
- Match them with a student's profile
