scholarships_db = [] 
